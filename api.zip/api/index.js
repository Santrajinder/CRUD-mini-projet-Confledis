const express = require('express');
const cors = require('cors');

const app = express();

app.use(cors());
app.use(express.json());

app.listen(5000, () => {
    console.log('Server is running on port 5000.');
});
let products = [];

app.get('/products', (req, res) => {
    res.json(products);
});

app.post('/products', (req, res) => {
    products.push(req.body);
    res.status(201).send();
});

app.put('/products/:name', (req, res) => {
    const product = products.find(p => p.name === req.params.name);
    if (product) {
        product.price = req.body.price;
        product.quantity = req.body.quantity;
        res.json(product);
    } else {
        res.status(404).send();
    }
});

app.delete('/products/:name', (req, res) => {
    products = products.filter(p => p.name !== req.params.name);
    res.status(200).send();
});
